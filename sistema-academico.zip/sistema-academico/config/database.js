import sql from 'mssql';

const dbConfig = {
  server: 'localhost', 
  user: 'sa',
  password: 'MyStrong!Password123',
  database: 'master',
  options: {
    encrypt: false,
    trustServerCertificate: true,
    connectTimeout: 60000, // Aumentado a 60 segundos
    instanceName: 'MSSQLSERVER' // Nombre de instancia por defecto
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

export const db = {
  pool: null,
  
  async connect() {
    if (!this.pool) {
      try {
        this.pool = await sql.connect(dbConfig);
        console.log('✅ Conexión exitosa a SQL Server en Docker');
      } catch (error) {
        console.error('❌ Error de conexión:', {
          message: error.message,
          code: error.code,
          stack: error.stack
        });
        throw error;
      }
    }
    return this.pool;
  },

  async query(sqlQuery, params = {}) {
    const pool = await this.connect();
    const request = pool.request();
    
    Object.entries(params).forEach(([key, value]) => {
      request.input(key, value);
    });

    try {
      const result = await request.query(sqlQuery);
      return result.recordset;
    } catch (error) {
      console.error('❌ Error en consulta:', {
        query: sqlQuery.substring(0, 100) + '...',
        error: error.message
      });
      throw error;
    }
  }
};