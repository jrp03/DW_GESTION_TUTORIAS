import sql from 'SQLEXPRESS';

const dbConfig = {
  server: 'localhost\\SQLEXPRESS',
  database: 'practicas_pruebas',
  options: {
    trustServerCertificate: true,
    encrypt: false
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

// Para Windows Authentication
if (process.env.SQL_AUTH === 'windows') {
  dbConfig.authentication = {
    type: 'default',
    options: {
      userName: '', // Vacío para Windows Auth
      password: ''  // Vacío para Windows Auth
    }
  };
} else {
  // Para autenticación SQL Server
  dbConfig.user = 'tu_usuario';
  dbConfig.password = 'tu_contraseña';
}

export const db = {
  pool: null,
  async connect() {
    if (!this.pool) {
      this.pool = await sql.connect(dbConfig);
      console.log('✅ Conexión exitosa a SQL Server');
    }
    return this.pool;
  },

  async query(sqlQuery, params = {}) {
    try {
      const pool = await this.connect();
      const request = pool.request();
      
      // Agrega parámetros con notación @param
      Object.entries(params).forEach(([key, value]) => {
        request.input(key, value);
      });

      const result = await request.query(sqlQuery);
      return {
        success: true,
        data: result.recordset,
        rowsAffected: result.rowsAffected
      };
    } catch (error) {
      console.error('❌ Error en consulta SQL:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }
};