import { db } from '../config/database.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runSetup() {
  try {
    // Ruta corregida - el archivo está en la misma carpeta que el script
    const sqlScript = fs.readFileSync(
      path.join(__dirname, 'usuarios.sql'), 
      'utf8'
    );

    console.log('✅ Archivo SQL encontrado correctamente');

    // Ejecuta cada lote separado por GO
    for (const batch of sqlScript.split('GO').filter(b => b.trim())) {
      await db.query(batch);
    }
    
    console.log('✅ Base de datos creada exitosamente');
  } catch (error) {
    console.error('❌ Error:', error.message);
    
    // Debug adicional
    console.log('Ruta buscada:', path.join(__dirname, 'usuarios.sql'));
    console.log('¿Existe el archivo?', fs.existsSync(path.join(__dirname, 'usuarios.sql')));
  }
}

runSetup();