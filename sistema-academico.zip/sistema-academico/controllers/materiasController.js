import { Materia } from '../models/materia.js';

export const materiasController = {
  getAll: async (req, res) => {
    const result = await Materia.getAll();
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(500).json({ error: result.error });
    }
  },

  getById: async (req, res) => {
    const result = await Materia.getById(req.params.id);
    if (result.success) {
      res.json(result.data[0] || {});
    } else {
      res.status(404).json({ error: result.error });
    }
  },

  create: async (req, res) => {
    const { id_materia, nombre_materia } = req.body;
    if (!id_materia || !nombre_materia) {
      return res.status(400).json({ error: 'Datos incompletos' });
    }

    const result = await Materia.create({ id_materia, nombre_materia });
    if (result.success) {
      res.status(201).json({ message: 'Materia creada' });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  update: async (req, res) => {
    const { id_materia, nombre_materia } = req.body;
    if (!id_materia || !nombre_materia) {
      return res.status(400).json({ error: 'Datos incompletos' });
    }

    const result = await Materia.update({ id_materia, nombre_materia });
    if (result.success) {
      res.json({ message: 'Materia actualizada' });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  delete: async (req, res) => {
    const result = await Materia.delete(req.params.id);
    if (result.success) {
      res.json({ message: 'Materia eliminada' });
    } else {
      res.status(400).json({ error: result.error });
    }
  }
};