import { Solicitud } from "../models/solicitud.js";

export const solicitudesController = {
  getAll: async (req, res) => {
    const result = await Solicitud.getAll();
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(500).json({ error: result.error });
    }
  },

  getById: async (req, res) => {
    const result = await Solicitud.getById(req.params.id);
    if (result.success) {
      res.json(result.data[0] || {});
    } else {
      res.status(404).json({ error: result.error });
    }
  },

  create: async (req, res) => {
    const { id_alumno, nombres, apellidos, carrera, asesor, materia } = req.body;
    
    if (!id_alumno || !nombres || !apellidos || !carrera || !asesor || !materia) {
      return res.status(400).json({ error: "Todos los campos son requeridos" });
    }

    const result = await Solicitud.create({
      id_alumno, nombres, apellidos, carrera, asesor, materia
    });

    if (result.success) {
      res.status(201).json({ message: "Solicitud creada exitosamente" });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  update: async (req, res) => {
    const { id_alumno, ...datos } = req.body;
    
    if (!id_alumno) {
      return res.status(400).json({ error: "ID de alumno requerido" });
    }

    const result = await Solicitud.update({ id_alumno, ...datos });
    if (result.success) {
      res.json({ message: "Solicitud actualizada" });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  delete: async (req, res) => {
    const { id } = req.params;
    const result = await Solicitud.delete(id);
    if (result.success) {
      res.json({ message: "Solicitud eliminada" });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  getMaterias: async (req, res) => {
    const result = await Solicitud.getMaterias();
    res.json(result);
  },

  getAsesores: async (req, res) => {
    const result = await Solicitud.getAsesores();
    res.json(result);
  }
};