import jwt from "jsonwebtoken";
import { Usuario } from "../models/usuario.js";

const JWT_SECRET = process.env.JWT_SECRET || "clave_secreta_temporal";

export const authController = {
  login: async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Usuario y contraseña requeridos" });
      }

      const usuario = await Usuario.verificarCredenciales(username, password);
      if (!usuario) {
        return res.status(401).json({ error: "Credenciales inválidas" });
      }

      const token = jwt.sign(
        { id: usuario.id, username: usuario.username, rol: usuario.rol },
        JWT_SECRET,
        { expiresIn: "8h" }
      );

      res.json({
        token,
        usuario: {
          id: usuario.id,
          username: usuario.username,
          nombre: usuario.nombre,
          rol: usuario.rol
        }
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  register: async (req, res) => {
    try {
      const { username, password, nombre, rol } = req.body;
      
      if (!username || !password || !nombre) {
        return res.status(400).json({ error: "Todos los campos son requeridos" });
      }

      const usuarioExistente = await Usuario.getByUsername(username);
      if (usuarioExistente.data?.length > 0) {
        return res.status(400).json({ error: "El usuario ya existe" });
      }

      const result = await Usuario.create({ username, password, nombre, rol });
      if (result.success) {
        res.status(201).json({ message: "Usuario registrado" });
      } else {
        res.status(400).json({ error: result.error });
      }
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  },

  verificarToken: (req, res) => {
    const token = req.headers.authorization?.split(" ")[1];
    
    if (!token) {
      return res.status(401).json({ error: "Token no proporcionado" });
    }

    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      res.json({ usuario: decoded });
    } catch (error) {
      res.status(401).json({ error: "Token inválido" });
    }
  }
};