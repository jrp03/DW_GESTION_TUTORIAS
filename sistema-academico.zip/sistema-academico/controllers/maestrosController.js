import { Maestro } from "../models/maestro.js";

export const maestrosController = {
  getAll: async (req, res) => {
    const result = await Maestro.getAll();
    if (result.success) {
      res.json(result.data);
    } else {
      res.status(500).json({ error: result.error });
    }
  },

  getById: async (req, res) => {
    const result = await Maestro.getById(req.params.id);
    if (result.success) {
      res.json(result.data[0] || {});
    } else {
      res.status(404).json({ error: result.error });
    }
  },

  create: async (req, res) => {
    const { id_maestro, nombres, apellidos, materia, carrera, telefono, correo } = req.body;
    
    if (!id_maestro || !nombres || !apellidos || !materia || !carrera || !telefono || !correo) {
      return res.status(400).json({ error: "Todos los campos son requeridos" });
    }

    const result = await Maestro.create({
      id_maestro, nombres, apellidos, materia, carrera, telefono, correo
    });

    if (result.success) {
      res.status(201).json({ message: "Maestro creado exitosamente" });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  update: async (req, res) => {
    const { id_maestro, ...datos } = req.body;
    
    if (!id_maestro) {
      return res.status(400).json({ error: "ID de maestro requerido" });
    }

    const result = await Maestro.update({ id_maestro, ...datos });
    if (result.success) {
      res.json({ message: "Maestro actualizado" });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  delete: async (req, res) => {
    const { id } = req.params;
    const result = await Maestro.delete(id);
    if (result.success) {
      res.json({ message: "Maestro eliminado" });
    } else {
      res.status(400).json({ error: result.error });
    }
  },

  getMaterias: async (req, res) => {
    const result = await Maestro.getMaterias();
    res.json(result);
  }
};