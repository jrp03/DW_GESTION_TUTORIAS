import express from "express";
import { solicitudesController } from "../controllers/solicitudesController.js";

const router = express.Router();

// Rutas RESTful para solicitudes
router.get("/", solicitudesController.getAll);
router.get("/:id", solicitudesController.getById);
router.post("/", solicitudesController.create);
router.put("/:id", solicitudesController.update);
router.delete("/:id", solicitudesController.delete);

// Rutas adicionales
router.get("/:id/materias", solicitudesController.getMaterias);
router.get("/:id/asesores", solicitudesController.getAsesores);

export default router;