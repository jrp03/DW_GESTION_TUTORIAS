import express from "express";
import { asesoresController } from "../controllers/asesoresController.js";

const router = express.Router();

// Rutas RESTful para asesores
router.get("/", asesoresController.getAll);
router.get("/:id", asesoresController.getById);
router.post("/", asesoresController.create);
router.put("/:id", asesoresController.update);
router.delete("/:id", asesoresController.delete);

// Rutas adicionales
router.get("/:id/materias", asesoresController.getMaterias);
router.get("/:id/maestros", asesoresController.getMaestros);

export default router;