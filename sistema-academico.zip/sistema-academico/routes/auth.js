import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { authController } from "../controllers/authController.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = express.Router();

// Configuración para servir archivos estáticos
const staticPath = path.join(__dirname, "../../public");

// Rutas GET para servir las páginas
router.get("/login", (req, res) => {
  res.sendFile(path.join(staticPath, "login.html"));
});

router.get("/register", (req, res) => {
  res.sendFile(path.join(staticPath, "register.html"));
});

// Rutas POST para el procesamiento
router.post("/login", authController.login);
router.post("/register", authController.register);
router.get("/verify", authController.verificarToken);

export default router;