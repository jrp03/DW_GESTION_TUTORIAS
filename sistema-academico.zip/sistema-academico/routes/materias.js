import express from "express";
import { materiasController } from "../controllers/materiasController.js";

const router = express.Router();

// Rutas RESTful para materias
router.get("/", materiasController.getAll);
router.get("/:id", materiasController.getById);
router.post("/", materiasController.create);
router.put("/:id", materiasController.update);
router.delete("/:id", materiasController.delete);

export default router;