import express from "express";
import { maestrosController } from "../controllers/maestrosController.js";

const router = express.Router();

// Rutas RESTful para maestros
router.get("/", maestrosController.getAll);
router.get("/:id", maestrosController.getById);
router.post("/", maestrosController.create);
router.put("/:id", maestrosController.update);
router.delete("/:id", maestrosController.delete);

// Ruta adicional
router.get("/:id/materias", maestrosController.getMaterias);

export default router;