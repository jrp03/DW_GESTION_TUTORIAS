import { db } from "../config/database.js";

export class Solicitud {
  static async getAll() {
    return await db.query('SELECT * FROM solicitud');
  }

  static async getById(id_alumno) {
    return await db.query(
      'SELECT * FROM solicitud WHERE id_alumno = @id',
      { id: id_alumno }
    );
  }

  static async create(solicitud) {
    return await db.query(
      `INSERT INTO solicitud 
      (id_alumno, nombres, apellidos, carrera, asesor, materia) 
      VALUES 
      (@id, @nombres, @apellidos, @carrera, @asesor, @materia)`,
      {
        id: solicitud.id_alumno,
        nombres: solicitud.nombres,
        apellidos: solicitud.apellidos,
        carrera: solicitud.carrera,
        asesor: solicitud.asesor,
        materia: solicitud.materia
      }
    );
  }

  static async update(solicitud) {
    return await db.query(
      `UPDATE solicitud SET 
      nombres = @nombres, 
      apellidos = @apellidos, 
      carrera = @carrera, 
      asesor = @asesor, 
      materia = @materia 
      WHERE id_alumno = @id`,
      {
        nombres: solicitud.nombres,
        apellidos: solicitud.apellidos,
        carrera: solicitud.carrera,
        asesor: solicitud.asesor,
        materia: solicitud.materia,
        id: solicitud.id_alumno
      }
    );
  }

  static async delete(id_alumno) {
    return await db.query(
      'DELETE FROM solicitud WHERE id_alumno = @id',
      { id: id_alumno }
    );
  }

  static async getMaterias() {
    const result = await db.query(
      'SELECT id_materia, nombre_materia FROM materias'
    );
    return result.success ? result.data : [];
  }

  static async getAsesores() {
    const result = await db.query(
      'SELECT id_alumno, nombre FROM alumnos WHERE nombre IS NOT NULL'
    );
    return result.success ? 
      result.data.map(a => ({ id_alumno: a.id_alumno, nombre_asesor: a.nombre })) : 
      [];
  }
}