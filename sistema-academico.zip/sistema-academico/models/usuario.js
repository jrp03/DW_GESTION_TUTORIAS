import { db } from "../config/database.js";
import bcrypt from "bcryptjs";

export class Usuario {
  static async getByUsername(username) {
    return await db.query(
      'SELECT * FROM usuarios WHERE username = @username',
      { username }
    );
  }

  static async create(usuario) {
    const hashedPassword = await bcrypt.hash(usuario.password, 10);
    
    return await db.query(
      'INSERT INTO usuarios (username, password, nombre, rol) VALUES (@username, @password, @nombre, @rol)',
      {
        username: usuario.username,
        password: hashedPassword,
        nombre: usuario.nombre,
        rol: usuario.rol || 'usuario'
      }
    );
  }

  static async verificarCredenciales(username, password) {
    const result = await this.getByUsername(username);
    
    if (!result.success || result.data.length === 0) return null;
    
    const usuario = result.data[0];
    const valido = await bcrypt.compare(password, usuario.password);
    
    if (!valido) return null;
    
    delete usuario.password;
    return usuario;
  }
}