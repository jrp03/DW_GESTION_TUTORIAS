import { db } from "../config/database.js";

export class Materia {
  static async getAll() {
    return await db.query('SELECT * FROM materias');
  }

  static async getById(id_materia) {
    return await db.query(
      'SELECT * FROM materias WHERE id_materia = @id',
      { id: id_materia }
    );
  }

  static async create({ id_materia, nombre_materia }) {
    return await db.query(
      'INSERT INTO materias (id_materia, nombre_materia) VALUES (@id, @nombre)',
      { id: id_materia, nombre: nombre_materia }
    );
  }

  static async update({ id_materia, nombre_materia }) {
    return await db.query(
      'UPDATE materias SET nombre_materia = @nombre WHERE id_materia = @id',
      { nombre: nombre_materia, id: id_materia }
    );
  }

  static async delete(id_materia) {
    return await db.query(
      'DELETE FROM materias WHERE id_materia = @id',
      { id: id_materia }
    );
  }
}